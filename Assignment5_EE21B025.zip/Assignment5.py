import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
import time

fig, ax = plt.subplots()
xdata, ydata = [], []
ln, = ax.plot([], [], "r", linewidth = 3)
plt.title(r"Ata Karim  EE21B025", fontsize = 18)
def init():
    ax.set_xlim(-2.4, 2.4)
    ax.set_ylim(-2.4,2.4)
    return ln,

def n_sided_polygon(n):
    alpha = 2*np.pi/n
    X_corner, Y_corner = [2*np.cos(i*alpha) for i in range(n)], [2*np.sin(i*alpha) for i in range(n)]
    return X_corner, Y_corner

def morph(x1, y1, x2, y2, alpha):
    """
        Here x1, y1 and x2, y2 are corner points of 
        final and initial polygon respectively
    """
    xm, ym = [], []
    xm.append(2)
    ym.append(0)
    if(alpha[2]=="Increasing Side"):
        for i in range(0,len(x2)):
            xm.append(alpha[1]*x1[i] + (1-alpha[1])*x2[i])
            ym.append(alpha[1]*y1[i] + (1-alpha[1])*y2[i])
            xm.append(alpha[1]*x1[i+1] + (1-alpha[1])*x2[i])
            ym.append(alpha[1]*y1[i+1] + (1-alpha[1])*y2[i])
    else:
        for i in range(0,len(x1)):
            xm.append(alpha[1]*x1[i] + (1-alpha[1])*x2[i])
            ym.append(alpha[1]*y1[i] + (1-alpha[1])*y2[i])
            xm.append(alpha[1]*x1[i] + (1-alpha[1])*x2[i+1])
            ym.append(alpha[1]*y1[i] + (1-alpha[1])*y2[i+1])
    xm.append(2)
    ym.append(0)
    return xm, ym

f = [] # frame is a list of tuple
for i in range(10):
    for j in range(20):
        if(i<=4):
            f.append((i+3, j/19, "Increasing Side",0 ))
        elif(i==5 and j==0):
            f.append((13-i, j/19, "Decreasing Side",1))
        else:
            f.append((13-i, j/19, "Decreasing Side",0))

def update(frame):
    if(frame[3]==1):
        time.sleep(3)
    if(frame[2]=="Increasing Side"):
        x1, y1 = n_sided_polygon(frame[0])[0], n_sided_polygon(frame[0])[1]
        x2, y2 = n_sided_polygon(frame[0]+1)[0], n_sided_polygon(frame[0]+1)[1]
    else:
        x1, y1 = n_sided_polygon(frame[0])[0], n_sided_polygon(frame[0])[1]
        x2, y2 = n_sided_polygon(frame[0]-1)[0], n_sided_polygon(frame[0]-1)[1]
    xdata, ydata = morph(x2, y2,x1, y1,frame)
    ln.set_data(xdata, ydata)
    return ln,


ani = FuncAnimation(fig, update, frames=f,init_func=init, blit=True, interval=10, repeat=False, repeat_delay=1000)
plt.show()